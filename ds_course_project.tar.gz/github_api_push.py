#!/usr/bin/env python3
"""使用 GitHub API 推送代码的脚本"""
import os
import base64
import requests
import json
from pathlib import Path

# GitHub 配置
REPO_OWNER = "JCC15484"
REPO_NAME = "ds_course"
BRANCH = "master"
TOKEN = "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"

# 文件路径列表（从 dist 目录开始）
FILES_TO_PUSH = [
    "dist/index.html",
    "dist/assets/index-BJgp5M2e.css",
    "dist/assets/index-CN-se-Qo.js",
    "dist/assets/__vite-browser-external-BIHI7g3E.js",
    "dist/favicon.svg",
    "src/pages/Home.tsx",
    "src/pages/Projects.tsx",
    "src/pages/ProjectDetail.tsx",
    "src/data/projects.ts",
    "src/components/PracticeEditor.tsx",
    "README.md"
]

def get_file_sha(file_path: str) -> str:
    """获取文件的现有 SHA"""
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{file_path}?ref={BRANCH}"
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.json().get("sha")
        return None
    except Exception as e:
        print(f"检查文件 {file_path} 出错: {e}")
        return None

def upload_file(file_path: str) -> bool:
    """上传单个文件"""
    print(f"📤 上传: {file_path}...")
    
    # 读取文件
    full_path = Path(__file__).parent / file_path
    if not full_path.exists():
        print(f"   ❌ 文件不存在: {file_path}")
        return False
    
    with open(full_path, "rb") as f:
        content = base64.b64encode(f.read()).decode("utf-8")
    
    # 获取现有 SHA
    sha = get_file_sha(file_path)
    
    # 准备请求
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{file_path}"
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    data = {
        "message": f"更新 {file_path}",
        "content": content,
        "branch": BRANCH
    }
    
    if sha:
        data["sha"] = sha
    
    try:
        response = requests.put(url, headers=headers, json=data)
        if response.status_code in [200, 201]:
            print(f"   ✅ 成功: {file_path}")
            return True
        else:
            print(f"   ❌ 失败 ({response.status_code}): {response.text}")
            return False
    except Exception as e:
        print(f"   ❌ 错误: {e}")
        return False

def main():
    print("🚀 开始通过 GitHub API 推送代码...")
    print("-" * 50)
    
    success_count = 0
    total_count = 0
    
    # 上传文件
    for file_path in FILES_TO_PUSH:
        total_count += 1
        if upload_file(file_path):
            success_count += 1
    
    # 总结
    print("-" * 50)
    print(f"✅ 完成! {success_count}/{total_count} 文件已成功上传")
    print()
    print("🌐 你的网站地址:")
    print(f"   https://{REPO_OWNER}.github.io/{REPO_NAME}/")
    print()
    print("📋 记得启用 GitHub Pages:")
    print("   https://github.com/JCC15484/ds_course/settings/pages")
    print("   Source: Deploy from a branch")
    print("   Branch: master / (root)")

if __name__ == "__main__":
    main()
