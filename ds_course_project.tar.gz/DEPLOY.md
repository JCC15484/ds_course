# 🚀 部署指南

## 方式一：使用 GitHub Actions 自动部署（推荐）

### 步骤 1：推送代码到 GitHub

在本地项目目录执行：

```bash
# 添加所有更改
git add -A

# 提交更改
git commit -m "添加10个Pandas实战项目"

# 使用 token 推送
git push https://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@github.com/JCC15484/ds_course.git master
```

### 步骤 2：启用 GitHub Pages

1. 访问仓库：https://github.com/JCC15484/ds_course
2. 点击 `Settings` → `Pages`
3. 在 `Build and deployment` 下选择：
   - Source: `Deploy from a branch`
   - Branch: `gh-pages` / (root)
4. 点击 `Save`

### 步骤 3：自动部署

推送代码到 `master` 分支后，GitHub Actions 会自动构建并部署。

---

## 方式二：使用 gh-pages 手动部署

### 1. 安装 gh-pages

```bash
npm install -D gh-pages
```

### 2. 部署

```bash
npm run deploy
```

---

## 方式三：直接上传 dist 文件夹

如果只需要快速部署：

1. 构建项目：`npm run build`
2. 将 `dist` 文件夹内容上传到任何静态托管服务

---

## 📝 项目信息

- **仓库地址**：https://github.com/JCC15484/ds_course
- **部署后网址**：https://JCC15484.github.io/ds_course/

## ✨ 功能特性

- 10个完整的Pandas实战项目
- 在线代码编辑器（使用Pyodide）
- 自动判题功能
- 学习步骤导航
- 完整的项目详情页面
