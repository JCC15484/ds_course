#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const https = require('https');

// GitHub 配置
const REPO_OWNER = 'JCC15484';
const REPO_NAME = 'ds_course';
const BRANCH = 'master';
const TOKEN = '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';

const DIST_PATH = path.join(__dirname, 'dist');

async function uploadFile(filePath, content) {
  const relativePath = path.relative(DIST_PATH, filePath).replace(/\\/g, '/');
  const encodedPath = encodeURIComponent(relativePath);
  const url = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${encodedPath}`;

  const contentBase64 = Buffer.from(content).toString('base64');

  const data = JSON.stringify({
    message: `Upload ${relativePath}`,
    content: contentBase64,
    branch: BRANCH
  });

  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.github.com',
      port: 443,
      path: url,
      method: 'PUT',
      headers: {
        'Authorization': `token ${TOKEN}`,
        'User-Agent': 'Node.js',
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data)
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        try {
          const result = JSON.parse(body);
          if (res.statusCode === 200 || res.statusCode === 201) {
            console.log(`✅ Uploaded: ${relativePath}`);
            resolve(result);
          } else {
            console.log(`❌ Failed: ${relativePath} - ${result.message || res.statusCode}`);
            reject(new Error(result.message || `HTTP ${res.statusCode}`));
          }
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

async function uploadDirectory(dirPath) {
  const files = [];

  function walkDir(currentPath) {
    const items = fs.readdirSync(currentPath);
    for (const item of items) {
      const fullPath = path.join(currentPath, item);
      const stat = fs.statSync(fullPath);

      if (stat.isDirectory()) {
        walkDir(fullPath);
      } else {
        files.push(fullPath);
      }
    }
  }

  walkDir(dirPath);

  console.log(`📁 Found ${files.length} files to upload\n`);

  for (const file of files) {
    try {
      const content = fs.readFileSync(file);
      await uploadFile(file, content);
      // 添加延迟避免 API 限流
      await new Promise(resolve => setTimeout(resolve, 100));
    } catch (e) {
      console.error(`Error uploading ${file}:`, e.message);
    }
  }
}

console.log('🚀 Starting deployment to GitHub Pages...\n');
uploadDirectory(DIST_PATH)
  .then(() => {
    console.log('\n✅ Deployment completed!');
    console.log('🌐 Your site should be available at:');
    console.log('   https://JCC15484.github.io/ds_course/');
  })
  .catch(console.error);
