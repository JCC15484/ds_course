# 🚀 部署指南 - 完整步骤

## 📋 准备工作

你需要在自己的电脑上执行以下操作：

### 1. 安装 Git

- Windows: https://git-scm.com/download/win
- Mac: 自带终端执行 `brew install git`
- Linux: `sudo apt install git`

### 2. 安装 Node.js

- 下载地址: https://nodejs.org/
- 建议安装 LTS 版本

---

## 🚀 部署步骤

### 步骤 1：克隆仓库

```bash
git clone https://github.com/JCC15484/ds_course.git
cd ds_course
```

### 步骤 2：安装依赖

```bash
npm install
```

### 步骤 3：构建项目

```bash
npm run build
```

### 步骤 4：配置远程仓库

```bash
# 设置用户信息
git config user.name "JCC15484"
git config user.email "14739592707@163.com"

# 添加远程仓库
git remote add origin https://github.com/JCC15484/ds_course.git
```

### 步骤 5：推送代码

```bash
# 使用 Personal Access Token 推送
git push https://JCC15484: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@github.com/JCC15484/ds_course.git master
```

---

## ⚙️ 配置 GitHub Pages

### 手动配置步骤

1. 打开浏览器访问: https://github.com/JCC15484/ds_course
2. 点击 `Settings` → `Pages`
3. 在 `Build and deployment` 下：
   - **Source**: `Deploy from a branch`
   - **Branch**: `master` / (root)
   - 点击 `Save`

### 自动部署 (GitHub Actions)

项目已配置 GitHub Actions，推送代码后会自动部署。

---

## 🔗 部署后网址

成功部署后，你的网站将在以下地址访问：

**https://JCC15484.github.io/ds_course/**

---

## 📁 项目结构

```
ds_course/
├── src/
│   ├── components/     # 组件
│   ├── pages/          # 页面
│   ├── data/           # 数据配置
│   └── ...
├── dist/              # 构建产物
├── package.json
├── vite.config.ts
└── README.md
```

---

## ✨ 功能特性

- ✅ 10个完整的Pandas实战项目
- ✅ 在线代码编辑器（Pyodide）
- ✅ 自动判题功能
- ✅ 学习步骤导航
- ✅ 代码运行和结果展示

---

## ⚠️ 常见问题

### Q1: 推送时提示 Permission denied

**解决方案**:
1. 检查 Token 是否正确
2. 检查 Token 是否有 `repo` 权限
3. 重新生成 Token（有效期建议设为90天）

### Q2: 页面显示空白

**解决方案**:
- 确保 `vite.config.ts` 中的 `base` 配置正确
- 检查控制台是否有错误信息

### Q3: GitHub Pages 不更新

**解决方案**:
- 等待几分钟（GitHub Pages 可能需要时间同步）
- 检查 Actions 日志是否有错误

---

## 📞 技术支持

如果遇到问题，可以：
1. 查看 GitHub Actions 日志
2. 检查浏览器控制台错误
3. 联系 GitHub 支持

---

祝你的网站部署成功！🎉
