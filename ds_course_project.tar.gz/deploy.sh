#!/bin/bash

# 部署脚本
echo "开始部署..."

# 检查是否有更改
git status

# 添加所有文件
git add -A

# 提交更改
git commit -m "添加10个Pandas实战项目"

# 使用 token 推送
git remote set-url origin https://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@github.com/JCC15484/ds_course.git

# 推送
echo "正在推送到 GitHub..."
git push -u origin master

echo "部署完成！"
