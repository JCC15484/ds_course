export interface ProjectStep {
  id: number;
  title: string;
  description: string;
  codeTemplate: string;
  expectedOutput: string;
}

export interface Project {
  id: number;
  title: string;
  difficulty: string;
  duration: string;
  tags: string[];
  category: string;
  description: string;
  learningGoals: string[];
  steps: ProjectStep[];
  icon: string;
  color: string;
}

export const projects: Project[] = [
  {
    id: 1,
    title: '销售数据基础分析',
    difficulty: '⭐入门',
    duration: '30分钟',
    tags: ['read_csv', 'to_datetime', 'groupby', 'pivot_table'],
    category: '数据分析',
    description: '学习Pandas基础操作，生成数据，处理日期，分组聚合和透视表分析',
    learningGoals: [
      '掌握数据生成和基本信息查看',
      '学会日期类型转换和脏数据清洗',
      '掌握groupby分组聚合操作',
      '学会创建和使用pivot_table透视表'
    ],
    icon: '📊',
    color: 'from-green-400 to-green-600',
    steps: [
      {
        id: 1,
        title: '步骤1：数据生成与查看',
        description: '生成销售数据并查看前5行、形状、列类型。',
        codeTemplate: `import pandas as pd
import numpy as np

# 生成模拟销售数据
np.random.seed(42)
dates = pd.date_range('2023-01-01', periods=1000)
products = np.random.choice(['iPhone', 'MacBook', 'iPad', 'AirPods', 'Apple Watch'], size=1000)
quantities = np.random.randint(1, 10, size=1000)
prices = np.random.choice([5999, 8999, 2999, 1299, 2499], size=1000)

df = pd.DataFrame({
    'date': dates,
    'product': products,
    'quantity': quantities,
    'price': prices
})

# 查看数据
print("前5行数据:")
print(df.head())
print("\\n数据形状:", df.shape)
print("\\n列类型:")
print(df.dtypes)`,
        expectedOutput: '显示5行数据，1000行×4列，date列为datetime类型。'
      },
      {
        id: 2,
        title: '步骤2：日期转换与清洗',
        description: '确保date列是datetime，演示缺失值处理。',
        codeTemplate: `# 确保date列是datetime类型
df['date'] = pd.to_datetime(df['date'], errors='coerce')

# 检查是否有无效日期
print("无效日期数:", df['date'].isna().sum())

# 假设我们添加一些缺失值来演示清洗
df.loc[np.random.choice(df.index, 10), 'quantity'] = np.nan

# 删除缺失值
df.dropna(subset=['date', 'quantity'], inplace=True)
print("清洗后数据行数:", len(df))`,
        expectedOutput: '打印无效日期数量（应该是0），剩余有效行数。'
      },
      {
        id: 3,
        title: '步骤3：特征工程',
        description: '提取年、月、星期几，计算订单金额。',
        codeTemplate: `# 从日期中提取特征
df['year'] = df['date'].dt.year
df['month'] = df['date'].dt.month
df['day_of_week'] = df['date'].dt.dayofweek
df['day_name'] = df['date'].dt.day_name()

# 计算订单金额
df['amount'] = df['quantity'] * df['price']

print("新增特征后的前5行:")
print(df[['date', 'month', 'day_name', 'amount']].head())`,
        expectedOutput: '显示新增的月份、星期几和金额列。'
      },
      {
        id: 4,
        title: '步骤4：分组聚合分析',
        description: '按月统计销售额，计算月增长率；找出销售额Top5产品。',
        codeTemplate: `# 按月统计销售额
monthly = df.groupby('month')['amount'].sum()
print("月度销售额:")
print(monthly)

# 计算月增长率
growth = monthly.pct_change() * 100
print("\\n月增长率(%):")
print(growth.round(2))

# 找出销售额Top5产品
top5 = df.groupby('product')['amount'].sum().sort_values(ascending=False).head(5)
print("\\nTop5产品销售额:")
print(top5)`,
        expectedOutput: '表格展示月度销售额及增长率，Top5产品列表。'
      },
      {
        id: 5,
        title: '步骤5：创建透视表',
        description: '生成产品×月份的销售矩阵透视表。',
        codeTemplate: `# 创建透视表
pivot = pd.pivot_table(
    df, 
    values='amount', 
    index='product', 
    columns='month', 
    aggfunc='sum', 
    fill_value=0
)

print("产品×月份销售透视表:")
print(pivot.round(0))`,
        expectedOutput: '行列整齐的产品×月份透视表。'
      }
    ]
  },
  {
    id: 2,
    title: '购物篮分析',
    difficulty: '⭐⭐进阶',
    duration: '45分钟',
    tags: ['crosstab', 'merge', '关联规则'],
    category: '数据挖掘',
    description: '学习购物篮分析方法，计算支持度、置信度和提升度，发现产品关联规则',
    learningGoals: [
      '掌握crosstab交叉表的使用',
      '学会计算产品的支持度',
      '掌握关联规则的计算方法',
      '学会筛选强关联规则'
    ],
    icon: '🛒',
    color: 'from-blue-400 to-blue-600',
    steps: [
      {
        id: 1,
        title: '步骤1：构建交易-产品矩阵',
        description: '生成交易数据并转换为二进制矩阵。',
        codeTemplate: `import pandas as pd
import numpy as np
from itertools import combinations

# 生成模拟购物篮数据
np.random.seed(42)
transaction_ids = np.repeat(range(1, 501), np.random.randint(1, 5, size=500))
products = np.random.choice(['牛奶', '面包', '鸡蛋', '苹果', '香蕉', '饼干', '果汁', '酸奶'], 
                           size=len(transaction_ids))

df = pd.DataFrame({
    'transaction_id': transaction_ids,
    'product': products
})

# 构建交易-产品矩阵
basket = pd.crosstab(df['transaction_id'], df['product'])
basket_bool = basket.astype(bool)

print("矩阵形状:", basket.shape)
print("\\n前5行数据:")
print(basket.head())`,
        expectedOutput: '500行×8列的稀疏矩阵预览。'
      },
      {
        id: 2,
        title: '步骤2：计算单项支持度',
        description: '计算每个产品的支持度（出现频率）。',
        codeTemplate: `# 计算支持度
support = basket.mean()
support_sorted = support.sort_values(ascending=False)

print("产品支持度（降序）:")
for product, sup in support_sorted.items():
    print(f"{product}: {sup:.2%}")`,
        expectedOutput: '每个产品的支持度降序排列。'
      },
      {
        id: 3,
        title: '步骤3：生成产品对并计算支持度',
        description: '生成所有产品组合，计算同时购买的支持度。',
        codeTemplate: `# 生成所有可能的产品对
product_pairs = list(combinations(basket.columns, 2))

# 计算每对产品的支持度
pair_support = {}
for a, b in product_pairs:
    pair_support[(a, b)] = ((basket[a] == 1) & (basket[b] == 1)).mean()

# 按支持度排序
sorted_pairs = sorted(pair_support.items(), key=lambda x: x[1], reverse=True)

print("前5个产品对支持度:")
for (a, b), sup in sorted_pairs[:5]:
    print(f"{a} & {b}: {sup:.2%}")`,
        expectedOutput: '打印5个产品对及其支持度。'
      },
      {
        id: 4,
        title: '步骤4：计算置信度与提升度',
        description: '计算关联规则的置信度和提升度。',
        codeTemplate: `# 生成关联规则
rules = []
for a, b in product_pairs:
    sup_a = support[a]
    sup_b = support[b]
    sup_ab = pair_support[(a, b)]
    
    if sup_ab > 0.01:  # 只考虑支持度>1%的规则
        confidence = sup_ab / sup_a
        lift = confidence / sup_b
        rules.append({
            'antecedent': a,
            'consequent': b,
            'support': sup_ab,
            'confidence': confidence,
            'lift': lift
        })

# 转换为DataFrame并排序
rules_df = pd.DataFrame(rules)
rules_df = rules_df.sort_values('lift', ascending=False)

print("提升度最高的10条规则:")
print(rules_df.head(10).round(3))`,
        expectedOutput: '提升度最高的10条规则。'
      },
      {
        id: 5,
        title: '步骤5：筛选强关联规则',
        description: '保留提升度>1.2且置信度>0.3的规则。',
        codeTemplate: `# 筛选强规则
strong_rules = rules_df[
    (rules_df['lift'] > 1.2) & 
    (rules_df['confidence'] > 0.3)
].sort_values('lift', ascending=False)

print("强关联规则:")
print(strong_rules.round(3))
print(f"\\n共找到 {len(strong_rules)} 条强规则")`,
        expectedOutput: '最终强关联规则表格。'
      }
    ]
  },
  {
    id: 3,
    title: '用户行为漏斗分析',
    difficulty: '⭐⭐进阶',
    duration: '40分钟',
    tags: ['shift', 'value_counts', '转化率'],
    category: '数据分析',
    description: '学习用户行为漏斗分析方法，统计各步骤转化率，找出流失环节',
    learningGoals: [
      '掌握用户行为事件统计方法',
      '学会计算时间间隔和转化漏斗',
      '掌握转化率的计算方法',
      '学会用户分群分析'
    ],
    icon: '📈',
    color: 'from-purple-400 to-purple-600',
    steps: [
      {
        id: 1,
        title: '步骤1：事件分布统计',
        description: '统计各种行为事件的发生次数。',
        codeTemplate: `import pandas as pd
import numpy as np

# 生成模拟用户行为数据
np.random.seed(42)
user_ids = np.random.randint(1, 201, size=1000)
events = np.random.choice(
    ['page_view', 'search', 'product_view', 'add_to_cart', 'checkout', 'purchase'],
    size=1000,
    p=[0.35, 0.25, 0.2, 0.1, 0.06, 0.04]
)
timestamps = pd.date_range('2023-01-01', periods=1000, freq='5min')

df = pd.DataFrame({
    'user_id': user_ids,
    'event': events,
    'timestamp': timestamps
})

# 统计事件分布
print("事件分布:")
print(df['event'].value_counts())`,
        expectedOutput: 'page_view、search、product_view等事件的分布统计。'
      },
      {
        id: 2,
        title: '步骤2：计算事件时间间隔',
        description: '按用户分组，计算前后事件的时间差。',
        codeTemplate: `# 按用户排序
df_sorted = df.sort_values(['user_id', 'timestamp'])

# 计算时间间隔
df_sorted['time_diff'] = df_sorted.groupby('user_id')['timestamp'].diff()
df_sorted['time_diff_min'] = df_sorted['time_diff'].dt.total_seconds() / 60

print("前10行数据（含时间间隔）:")
print(df_sorted[['user_id', 'event', 'time_diff_min']].head(10))`,
        expectedOutput: '显示每个事件距上一事件的时间差（首个为NaN）。'
      },
      {
        id: 3,
        title: '步骤3：漏斗步骤定义与用户数统计',
        description: '定义漏斗步骤，统计每一步的独立用户数。',
        codeTemplate: `# 定义漏斗步骤顺序
funnel_steps = ['page_view', 'product_view', 'add_to_cart', 'checkout', 'purchase']

# 统计每一步的独立用户数
funnel = {}
for step in funnel_steps:
    funnel[step] = df[df['event'] == step]['user_id'].nunique()

funnel_df = pd.DataFrame(
    list(funnel.items()), 
    columns=['步骤', '用户数']
)

print("漏斗各步骤用户数:")
print(funnel_df)`,
        expectedOutput: '每个步骤的用户数统计。'
      },
      {
        id: 4,
        title: '步骤4：计算总体转化率和步骤转化率',
        description: '计算总体转化率和相邻步骤的转化率。',
        codeTemplate: `# 计算总体转化率（相对于第一步）
funnel_df['总体转化率%'] = (
    funnel_df['用户数'] / funnel_df.iloc[0, 1] * 100
).round(2)

# 计算步骤转化率（相对于上一步）
funnel_df['步骤转化率%'] = (
    funnel_df['用户数'] / funnel_df['用户数'].shift(1) * 100
).round(2)

print("完整漏斗分析:")
print(funnel_df)`,
        expectedOutput: '完整的漏斗转化率表格。'
      },
      {
        id: 5,
        title: '步骤5：用户活跃度分群',
        description: '根据用户行为次数，用cut分成低/中/高/超级活跃。',
        codeTemplate: `# 统计每个用户的事件数
event_count = df.groupby('user_id')['event'].count()

# 分群
segments = pd.cut(
    event_count, 
    bins=[0, 3, 7, 15, float('inf')],
    labels=['低活跃', '中活跃', '高活跃', '超级活跃']
)

print("用户活跃度分布:")
print(segments.value_counts().sort_index())`,
        expectedOutput: '各活跃度段用户数统计。'
      }
    ]
  },
  {
    id: 4,
    title: 'RFM客户价值分析',
    difficulty: '⭐⭐进阶',
    duration: '50分钟',
    tags: ['groupby', 'qcut', 'apply'],
    category: '客户分析',
    description: '学习RFM客户价值分析方法，根据最近购买、购买频率和消费金额分层客户',
    learningGoals: [
      '掌握RFM指标的计算方法',
      '学会qcut分组打分',
      '掌握apply函数自定义分层逻辑',
      '学会客户分群和统计分析'
    ],
    icon: '💎',
    color: 'from-orange-400 to-orange-600',
    steps: [
      {
        id: 1,
        title: '步骤1：计算R、F、M值',
        description: '计算每个客户的最近购买、购买频率和消费总额。',
        codeTemplate: `import pandas as pd
import numpy as np

# 生成模拟订单数据
np.random.seed(42)
customer_ids = np.random.randint(1, 501, size=2000)
order_dates = pd.date_range('2023-01-01', '2023-12-31', periods=2000)
order_amounts = np.random.randint(50, 5000, size=2000)

df = pd.DataFrame({
    'customer_id': customer_ids,
    'order_date': order_dates,
    'order_amount': order_amounts
})

# 计算RFM指标
reference_date = pd.to_datetime('2023-12-31')
rfm = df.groupby('customer_id').agg(
    last_order=('order_date', 'max'),
    frequency=('order_date', 'count'),
    monetary=('order_amount', 'sum')
)

rfm['recency'] = (reference_date - rfm['last_order']).dt.days
rfm.drop('last_order', axis=1, inplace=True)

print("RFM指标前5行:")
print(rfm.head())`,
        expectedOutput: 'RFM三列数据展示。'
      },
      {
        id: 2,
        title: '步骤2：用qcut进行RFM打分',
        description: '每个维度按四分位打1-4分（4为最好）。',
        codeTemplate: `# R值越小越好，所以反过来
rfm['R_score'] = pd.qcut(rfm['recency'], 4, labels=[4, 3, 2, 1])

# F和M值越大越好
rfm['F_score'] = pd.qcut(rfm['frequency'], 4, labels=[1, 2, 3, 4])
rfm['M_score'] = pd.qcut(rfm['monetary'], 4, labels=[1, 2, 3, 4])

# 组合得分
rfm['RFM_score'] = (
    rfm['R_score'].astype(str) + 
    rfm['F_score'].astype(str) + 
    rfm['M_score'].astype(str)
)

print("RFM打分后前5行:")
print(rfm.head())`,
        expectedOutput: '多了R、F、M得分和组合分数。'
      },
      {
        id: 3,
        title: '步骤3：定义客户分层函数',
        description: '根据R、F、M得分高低划分客户层级。',
        codeTemplate: `def rfm_segment(row):
    R = int(row['R_score'])
    F = int(row['F_score'])
    M = int(row['M_score'])
    
    if R >= 3 and F >= 3 and M >= 3:
        return '重要价值客户'
    elif R >= 3 and F <= 2:
        return '重要发展客户'
    elif R <= 2 and F >= 3:
        return '重要保持客户'
    elif R <= 2 and F <= 2:
        return '重要挽留客户'
    else:
        return '一般客户'

rfm['segment'] = rfm.apply(rfm_segment, axis=1)

print("客户分层分布:")
print(rfm['segment'].value_counts())`,
        expectedOutput: '各层级客户数量分布。'
      },
      {
        id: 4,
        title: '步骤4：分层统计',
        description: '计算各客户层级的RFM均值。',
        codeTemplate: `# 各层级统计
stats = rfm.groupby('segment').agg({
    'recency': 'mean',
    'frequency': 'mean',
    'monetary': 'mean',
    'customer_id': 'count'  # 客户数
}).round(1)

stats.columns = ['平均最近购买(天)', '平均购买频率', '平均消费金额', '客户数']

print("各客户层级统计:")
print(stats)`,
        expectedOutput: '表格展示不同层级的平均RFM值。'
      }
    ]
  },
  {
    id: 5,
    title: '股票数据技术分析',
    difficulty: '⭐⭐⭐挑战',
    duration: '60分钟',
    tags: ['rolling', 'ewm', 'apply'],
    category: '金融分析',
    description: '学习股票技术分析指标，计算MA、MACD、RSI、布林带等技术指标',
    learningGoals: [
      '掌握移动平均线MA的计算',
      '学会MACD指标的计算',
      '掌握自定义技术指标函数',
      '学会布林带计算和重采样'
    ],
    icon: '📉',
    color: 'from-red-400 to-red-600',
    steps: [
      {
        id: 1,
        title: '步骤1：移动平均线与交叉信号',
        description: '计算5日和20日移动平均，标记金叉死叉。',
        codeTemplate: `import pandas as pd
import numpy as np

# 生成模拟股票数据
np.random.seed(42)
dates = pd.date_range('2023-01-01', periods=250)
base_price = 100
returns = np.random.normal(0.001, 0.02, size=250)
prices = base_price * (1 + returns).cumprod()

df = pd.DataFrame({
    'date': dates,
    'close': prices,
    'open': prices * (1 + np.random.normal(0, 0.01, 250)),
    'high': prices * (1 + np.random.uniform(0, 0.03, 250)),
    'low': prices * (1 - np.random.uniform(0, 0.03, 250)),
    'volume': np.random.randint(100000, 1000000, 250)
})

# 计算移动平均线
df['MA5'] = df['close'].rolling(5).mean()
df['MA20'] = df['close'].rolling(20).mean()

# 生成交易信号
df['signal'] = 0
df.loc[df['MA5'] > df['MA20'], 'signal'] = 1
df['position'] = df['signal'].diff()

print("最后10行数据:")
print(df[['close', 'MA5', 'MA20', 'position']].tail(10))`,
        expectedOutput: '出现1为金叉，-1为死叉。'
      },
      {
        id: 2,
        title: '步骤2：MACD指标',
        description: '计算EMA12、EMA26，得到MACD线、信号线和柱状图。',
        codeTemplate: `# 计算EMA
exp12 = df['close'].ewm(span=12, adjust=False).mean()
exp26 = df['close'].ewm(span=26, adjust=False).mean()

# MACD线
df['MACD'] = exp12 - exp26

# 信号线
df['Signal_line'] = df['MACD'].ewm(span=9, adjust=False).mean()

# MACD柱状图
df['MACD_hist'] = df['MACD'] - df['Signal_line']

print("MACD指标最后10行:")
print(df[['close', 'MACD', 'Signal_line', 'MACD_hist']].tail(10))`,
        expectedOutput: 'MACD三列数据展示。'
      },
      {
        id: 3,
        title: '步骤3：自定义RSI函数',
        description: '编写计算14日RSI的函数。',
        codeTemplate: `def calculate_rsi(series, period=14):
    """计算RSI指标"""
    delta = series.diff()
    
    # 分离涨跌
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    
    # 计算平均涨跌
    avg_gain = gain.rolling(period).mean()
    avg_loss = loss.rolling(period).mean()
    
    # 计算RS和RSI
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi

df['RSI'] = calculate_rsi(df['close'])

print("RSI指标最后10行:")
print(df[['close', 'RSI']].tail(10))`,
        expectedOutput: 'RSI值在0-100之间。'
      },
      {
        id: 4,
        title: '步骤4：布林带',
        description: '计算20日均线和上下轨（2倍标准差）。',
        codeTemplate: `# 计算布林带
df['BB_mid'] = df['close'].rolling(20).mean()
std = df['close'].rolling(20).std()

df['BB_up'] = df['BB_mid'] + 2 * std
df['BB_low'] = df['BB_mid'] - 2 * std

print("布林带最后10行:")
print(df[['close', 'BB_mid', 'BB_up', 'BB_low']].tail(10))`,
        expectedOutput: '布林带三线数据展示。'
      },
      {
        id: 5,
        title: '步骤5：周线重采样',
        description: '将日线数据聚合成周线。',
        codeTemplate: `# 设置日期为索引
df_indexed = df.set_index('date')

# 重采样为周线
weekly = df_indexed.resample('W').agg({
    'open': 'first',
    'high': 'max',
    'low': 'min',
    'close': 'last',
    'volume': 'sum'
})

print("周线数据前10行:")
print(weekly.head(10))`,
        expectedOutput: '周线数据表格展示。'
      }
    ]
  },
  {
    id: 6,
    title: '文本数据情感分析',
    difficulty: '⭐入门',
    duration: '35分钟',
    tags: ['str', 'apply', '词频'],
    category: '文本分析',
    description: '学习文本数据分析基本方法，计算文本长度、情感分类、词频统计',
    learningGoals: [
      '掌握字符串操作方法',
      '学会关键词检测和情感分类',
      '掌握词频统计方法',
      '学会分组统计分析'
    ],
    icon: '💬',
    color: 'from-cyan-400 to-cyan-600',
    steps: [
      {
        id: 1,
        title: '步骤1：文本长度与关键词检测',
        description: '计算文本长度，检查是否包含正面/负面词。',
        codeTemplate: `import pandas as pd
import numpy as np

# 生成模拟评论数据
np.random.seed(42)
reviews = [
    "这个产品真的很好用，推荐购买！",
    "质量很差，非常失望，不建议买",
    "还可以吧，中规中矩",
    "太棒了！非常喜欢，物超所值",
    "一般般，没有想象中的好",
    "很好的购物体验，客服态度也不错",
    "快递太慢了，等了好久",
    "性价比很高，值得入手",
    "不太好用，有点后悔",
    "非常满意！下次还会来"
] * 20  # 复制20份

ratings = np.random.choice([1, 2, 3, 4, 5], size=200, p=[0.1, 0.1, 0.2, 0.3, 0.3])

df = pd.DataFrame({
    'text': reviews,
    'rating': ratings
})

# 计算文本长度
df['text_len'] = df['text'].str.len()

# 检测正负向词汇
positive_words = ['好', '棒', '喜欢', '推荐', '满意', '值得', '太棒']
negative_words = ['差', '失望', '不好', '后悔', '糟糕', '慢', '太']

df['is_positive'] = df['text'].str.contains('|'.join(positive_words))
df['is_negative'] = df['text'].str.contains('|'.join(negative_words))

print("前5行数据:")
print(df[['text', 'is_positive', 'is_negative']].head())`,
        expectedOutput: '布尔列指示情感。'
      },
      {
        id: 2,
        title: '步骤2：根据评分生成情感标签',
        description: '评分>=4为正面，<=2为负面，其余中性。',
        codeTemplate: `def label_sentiment(rating):
    if rating >= 4:
        return '正面'
    elif rating <= 2:
        return '负面'
    else:
        return '中性'

df['sentiment'] = df['rating'].apply(label_sentiment)

print("情感标签分布:")
print(df['sentiment'].value_counts())`,
        expectedOutput: '三类情感计数统计。'
      },
      {
        id: 3,
        title: '步骤3：高频词统计',
        description: '拼接所有文本，分割后统计词频。',
        codeTemplate: `# 简单分词（实际项目中建议使用jieba）
all_text = ' '.join(df['text'].values)
words = list(all_text)  # 按字符分割作为演示

# 统计词频
word_freq = pd.Series(words).value_counts().head(20)

print("高频字Top20:")
print(word_freq)`,
        expectedOutput: 'Top20高频字统计。'
      },
      {
        id: 4,
        title: '步骤4：各情感类别的文本长度分析',
        description: '按情感分组计算平均文本长度和评论数。',
        codeTemplate: `# 分组统计
stats = df.groupby('sentiment').agg({
    'text_len': 'mean',
    'text': 'count'
})

stats.columns = ['平均文本长度', '评论数']

print("各情感类别统计:")
print(stats.round(1))`,
        expectedOutput: '各情感类别的统计表格。'
      }
    ]
  },
  {
    id: 7,
    title: '多表关联与数据整合',
    difficulty: '⭐⭐进阶',
    duration: '50分钟',
    tags: ['merge', 'concat', 'pivot', 'melt'],
    category: '数据整合',
    description: '学习多表合并操作，掌握merge、concat、pivot、melt等函数',
    learningGoals: [
      '掌握merge各种连接操作',
      '学会concat拼接方法',
      '掌握pivot_table透视表',
      '学会melt长表宽表转换'
    ],
    icon: '🔗',
    color: 'from-yellow-400 to-yellow-600',
    steps: [
      {
        id: 1,
        title: '步骤1：内连接三张表',
        description: '将订单、用户、产品三表merge，得到完整订单详情。',
        codeTemplate: `import pandas as pd
import numpy as np

# 生成用户表
users = pd.DataFrame({
    'user_id': range(1, 101),
    'name': [f'用户{i}' for i in range(1, 101)],
    'city': np.random.choice(['北京', '上海', '广州', '深圳', '杭州'], 100),
    'age': np.random.randint(18, 60, 100)
})

# 生成产品表
products = pd.DataFrame({
    'product_id': range(1, 51),
    'product_name': [f'产品{i}' for i in range(1, 51)],
    'category': np.random.choice(['电子产品', '服装', '食品', '家居'], 50),
    'price': np.random.randint(10, 1000, 50)
})

# 生成订单表
orders = pd.DataFrame({
    'order_id': range(1, 501),
    'user_id': np.random.randint(1, 101, 500),
    'product_id': np.random.randint(1, 51, 500),
    'quantity': np.random.randint(1, 10, 500),
    'order_date': pd.date_range('2023-01-01', periods=500)
})

# 内连接三张表
order_details = orders.merge(users, on='user_id', how='inner')
order_details = order_details.merge(products, on='product_id', how='inner')
order_details['total_amount'] = order_details['quantity'] * order_details['price']

print("订单详情前5行:")
print(order_details[['order_id', 'name', 'product_name', 'total_amount']].head())`,
        expectedOutput: '宽表前5行数据。'
      },
      {
        id: 2,
        title: '步骤2：左连接与未匹配检查',
        description: '以订单表为主，左连接用户表，查找无用户信息的订单。',
        codeTemplate: `# 左连接
all_orders = orders.merge(users[['user_id', 'name', 'city']], on='user_id', how='left')

# 查找未匹配的订单
unmatched = all_orders[all_orders['name'].isna()]
print("未匹配订单数:", len(unmatched))`,
        expectedOutput: '未匹配订单数（应该是0）。'
      },
      {
        id: 3,
        title: '步骤3：concat拼接多月数据',
        description: '模拟1月和2月数据纵向拼接。',
        codeTemplate: `# 分割数据
jan_orders = orders[orders['order_date'].dt.month == 1]
feb_orders = orders[orders['order_date'].dt.month == 2]

# 拼接
combined = pd.concat([jan_orders, feb_orders], ignore_index=True)

print(f"1月订单数: {len(jan_orders)}")
print(f"2月订单数: {len(feb_orders)}")
print(f"合计订单数: {len(combined)}")`,
        expectedOutput: '1月、2月、合计订单数统计。'
      },
      {
        id: 4,
        title: '步骤4：pivot_table创建透视表',
        description: '按品类和季度汇总销售额。',
        codeTemplate: `# 添加季度列
order_details['quarter'] = order_details['order_date'].dt.quarter

# 创建透视表
quarterly = order_details.pivot_table(
    values='total_amount',
    index='category',
    columns='quarter',
    aggfunc='sum',
    fill_value=0
)

quarterly.columns = [f'Q{int(col)}' for col in quarterly.columns]

print("品类×季度销售透视表:")
print(quarterly.round(0))`,
        expectedOutput: '品类×季度销售表格。'
      },
      {
        id: 5,
        title: '步骤5：melt长表转回',
        description: '将透视表转回长表格式。',
        codeTemplate: `# 重置索引
quarterly_reset = quarterly.reset_index()

# 转换为长表
long_df = quarterly_reset.melt(
    id_vars='category',
    var_name='quarter',
    value_name='sales'
)

print("长表格式前10行:")
print(long_df.head(10))`,
        expectedOutput: '三列的长表格式。'
      }
    ]
  },
  {
    id: 8,
    title: '缺失值与异常值处理',
    difficulty: '⭐入门',
    duration: '40分钟',
    tags: ['fillna', 'interpolate', 'IQR'],
    category: '数据清洗',
    description: '学习数据清洗方法，处理缺失值和异常值，提高数据质量',
    learningGoals: [
      '掌握缺失值检测方法',
      '学会填充缺失值的多种方法',
      '掌握IQR法检测异常值',
      '学会处理异常值的方法'
    ],
    icon: '🧹',
    color: 'from-pink-400 to-pink-600',
    steps: [
      {
        id: 1,
        title: '步骤1：检测缺失值',
        description: '统计各列缺失数量和比例。',
        codeTemplate: `import pandas as pd
import numpy as np

# 生成含缺失值的数据
np.random.seed(42)
dates = pd.date_range('2023-01-01', periods=100)
temperature = 20 + 5 * np.sin(np.linspace(0, 4*np.pi, 100)) + np.random.normal(0, 1, 100)
humidity = 60 + 20 * np.random.random(100)

# 人为添加缺失值
temperature[np.random.choice(100, 10)] = np.nan
humidity[np.random.choice(100, 8)] = np.nan

df = pd.DataFrame({
    'date': dates,
    'temperature': temperature,
    'humidity': humidity
})

# 统计缺失值
print("缺失值统计:")
print(df.isna().sum())
print("\\n缺失比例:")
print((df.isna().sum() / len(df) * 100).round(2))`,
        expectedOutput: '各列缺失值统计。'
      },
      {
        id: 2,
        title: '步骤2：填充缺失值（前向、均值、插值）',
        description: '演示三种填充方法。',
        codeTemplate: `# 方法1：前向填充
df_ffill = df.fillna(method='ffill')

# 方法2：均值填充
df_mean = df.copy()
df_mean['temperature'] = df_mean['temperature'].fillna(df_mean['temperature'].mean())
df_mean['humidity'] = df_mean['humidity'].fillna(df_mean['humidity'].mean())

# 方法3：时间插值
df_interp = df.set_index('date').interpolate(method='time').reset_index()

print("前向填充后缺失数:", df_ffill.isna().sum().sum())
print("均值填充后缺失数:", df_mean.isna().sum().sum())
print("插值后缺失数:", df_interp.isna().sum().sum())`,
        expectedOutput: '各种填充方法后的缺失数（都应该是0）。'
      },
      {
        id: 3,
        title: '步骤3：IQR法检测异常值',
        description: '对temperature列计算四分位数，找出异常值。',
        codeTemplate: `# 使用填充后的数据
df_clean = df_interp.copy()

# 计算IQR
Q1 = df_clean['temperature'].quantile(0.25)
Q3 = df_clean['temperature'].quantile(0.75)
IQR = Q3 - Q1

lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

# 找出异常值
outliers = df_clean[
    (df_clean['temperature'] < lower) | 
    (df_clean['temperature'] > upper)
]

print(f"异常值范围: [{lower:.2f}, {upper:.2f}]")
print(f"异常值个数: {len(outliers)}")
if len(outliers) > 0:
    print("\\n异常值:")
    print(outliers)`,
        expectedOutput: '异常值数量和详情。'
      },
      {
        id: 4,
        title: '步骤4：处理异常值（中位数替换/clip）',
        description: '用中位数替换或截断处理异常值。',
        codeTemplate: `# 方法1：中位数替换
median_temp = df_clean['temperature'].median()
df_median_replace = df_clean.copy()
df_median_replace.loc[
    (df_clean['temperature'] < lower) | (df_clean['temperature'] > upper),
    'temperature'
] = median_temp

# 方法2：截断（clip）
df_clipped = df_clean.copy()
df_clipped['temperature'] = df_clipped['temperature'].clip(lower, upper)

print("原始数据统计:")
print(df_clean['temperature'].describe().round(2))
print("\\n中位数替换后统计:")
print(df_median_replace['temperature'].describe().round(2))
print("\\n截断后统计:")
print(df_clipped['temperature'].describe().round(2))`,
        expectedOutput: '异常值处理后的数据统计对比。'
      }
    ]
  },
  {
    id: 9,
    title: '数据透视与多维度交叉分析',
    difficulty: '⭐⭐⭐挑战',
    duration: '55分钟',
    tags: ['pivot_table', 'transform', '同比环比'],
    category: '高级分析',
    description: '学习多维度数据透视分析，计算同比环比，掌握高级分组技巧',
    learningGoals: [
      '掌握多维度透视表创建',
      '学会groupby+unstack方法',
      '掌握同比环比计算',
      '学会transform和高级索引操作'
    ],
    icon: '📊',
    color: 'from-teal-400 to-teal-600',
    steps: [
      {
        id: 1,
        title: '步骤1：多维度透视表（多index和columns）',
        description: '创建门店+品类为行，年份为列的销售额透视表。',
        codeTemplate: `import pandas as pd
import numpy as np

# 生成模拟销售数据
np.random.seed(42)
stores = ['门店A', '门店B', '门店C', '门店D', '门店E']
categories = ['食品', '服装', '电子产品', '家居']
years = [2022, 2023]
months = range(1, 13)

data = []
for store in stores:
    for year in years:
        for month in months:
            for category in categories:
                sales = np.random.randint(10000, 100000)
                data.append({
                    'store': store,
                    'category': category,
                    'year': year,
                    'month': month,
                    'sales': sales
                })

df = pd.DataFrame(data)

# 多维度透视表
pivot = pd.pivot_table(
    df,
    values='sales',
    index=['store', 'category'],
    columns='year',
    aggfunc='sum',
    margins=True
)

print("多维度透视表前10行:")
print(pivot.head(10).round(0))`,
        expectedOutput: '带合计的多维透视表。'
      },
      {
        id: 2,
        title: '步骤2：groupby+unstack实现类似透视',
        description: '先groupby再用unstack展开。',
        codeTemplate: `# groupby后unstack
matrix = df.groupby(['store', 'month'])['sales'].sum().unstack()

print("门店×月份销售矩阵前5行:")
print(matrix.head().round(0))`,
        expectedOutput: '门店×月份的销售矩阵。'
      },
      {
        id: 3,
        title: '步骤3：计算环比和同比',
        description: '先按年月汇总，然后pct_change算环比，按月份分组shift算同比。',
        codeTemplate: `# 按年月汇总
monthly = df.groupby(['year', 'month'])['sales'].sum().reset_index()
monthly = monthly.sort_values(['year', 'month'])

# 计算环比
monthly['mom%'] = monthly['sales'].pct_change() * 100

# 计算同比
monthly['yoy%'] = monthly.groupby('month')['sales'].pct_change(periods=1) * 100

print("月度销售及同比环比前12行:")
print(monthly.round(2).head(12))`,
        expectedOutput: '环比和同比列的数据。'
      },
      {
        id: 4,
        title: '步骤4：transform计算组内占比',
        description: '计算每个门店内各品类的销售占比。',
        codeTemplate: `# 计算门店年度总销售
df['store_year_total'] = df.groupby(['store', 'year'])['sales'].transform('sum')

# 计算占比
df['pct_of_store'] = (df['sales'] / df['store_year_total'] * 100).round(2)

print("组内占比前10行:")
print(df[['store', 'category', 'year', 'sales', 'pct_of_store']].head(10))`,
        expectedOutput: '多了占比列的数据。'
      },
      {
        id: 5,
        title: '步骤5：多层级索引的切片',
        description: '对多级索引进行取值和交换层级。',
        codeTemplate: `# 创建多级索引透视表
pivot_multi = pd.pivot_table(
    df,
    index=['store', 'category'],
    columns='year',
    values='sales',
    aggfunc='sum'
)

print("多级索引透视表:")
print(pivot_multi.round(0))
print("\\n---\\n")

# 切片：获取门店A的数据
print("门店A的销售数据:")
print(pivot_multi.loc['门店A'].round(0))
print("\\n---\\n")

# 交换层级
print("交换层级后的透视表:")
print(pivot_multi.swaplevel().round(0).head(10))`,
        expectedOutput: '正确切片和交换后的表。'
      }
    ]
  },
  {
    id: 10,
    title: '大数据分块处理与性能优化',
    difficulty: '⭐⭐⭐挑战',
    duration: '70分钟',
    tags: ['chunksize', 'category', 'eval', '向量化'],
    category: '性能优化',
    description: '学习大数据处理技巧，优化内存占用，提升计算速度',
    learningGoals: [
      '掌握分块读取大数据方法',
      '学会数据类型优化',
      '掌握eval和query加速',
      '学会向量化操作和按需加载'
    ],
    icon: '⚡',
    color: 'from-indigo-400 to-indigo-600',
    steps: [
      {
        id: 1,
        title: '步骤1：分块处理模拟',
        description: '模拟分块读取并聚合数据。',
        codeTemplate: `import pandas as pd
import numpy as np
import time

# 生成大型数据集
np.random.seed(42)
n_rows = 100000

df = pd.DataFrame({
    'id': range(n_rows),
    'category': np.random.choice(['A', 'B', 'C', 'D', 'E'], n_rows),
    'value1': np.random.randn(n_rows),
    'value2': np.random.randn(n_rows),
    'value3': np.random.randn(n_rows)
})

# 模拟分块处理
chunk_size = 10000
chunk_list = []

for i in range(0, n_rows, chunk_size):
    chunk = df.iloc[i:i+chunk_size]
    chunk_agg = chunk.groupby('category')['value1'].sum()
    chunk_list.append(chunk_agg)

# 合并结果
result = pd.concat(chunk_list).groupby(level=0).sum()

print("分块聚合结果:")
print(result.round(2))`,
        expectedOutput: '各类别的value1总和。'
      },
      {
        id: 2,
        title: '步骤2：数据类型优化',
        description: '查看内存占用，将object转为category，优化数值类型。',
        codeTemplate: `# 查看初始内存
print("优化前内存占用:")
print(f"{df.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB")

# 优化类型
df_optimized = df.copy()
df_optimized['category'] = df_optimized['category'].astype('category')
df_optimized['id'] = df_optimized['id'].astype('int32')

# 查看优化后内存
print("\\n优化后内存占用:")
print(f"{df_optimized.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB")

# 对比各列内存
print("\\n各列内存对比:")
memory_compare = pd.DataFrame({
    '原内存(MB)': df.memory_usage(deep=True) / 1024 / 1024,
    '优化后(MB)': df_optimized.memory_usage(deep=True) / 1024 / 1024
})
print(memory_compare.round(4))`,
        expectedOutput: '明显减少的内存占用。'
      },
      {
        id: 3,
        title: '步骤3：使用eval和query加速',
        description: '用df.eval()创建新列，df.query()筛选，对比传统方法速度。',
        codeTemplate: `# 传统方法
start = time.time()
df['sum_val'] = df['value1'] + df['value2'] + df['value3']
traditional_time = time.time() - start

# eval方法
start = time.time()
df.eval('sum_val2 = value1 + value2 + value3', inplace=True)
eval_time = time.time() - start

print(f"传统方法耗时: {traditional_time:.4f}秒")
print(f"eval方法耗时: {eval_time:.4f}秒")
print(f"加速比: {traditional_time / eval_time:.2f}x")

# query筛选对比
start = time.time()
filtered1 = df[(df['value1'] > 0) & (df['value2'] < 0)]
traditional_filter_time = time.time() - start

start = time.time()
filtered2 = df.query('value1 > 0 and value2 < 0')
query_time = time.time() - start

print(f"\\n传统筛选耗时: {traditional_filter_time:.4f}秒")
print(f"query筛选耗时: {query_time:.4f}秒")
print(f"加速比: {traditional_filter_time / query_time:.2f}x")`,
        expectedOutput: 'eval和query的性能对比，应该更快。'
      },
      {
        id: 4,
        title: '步骤4：apply、map与向量化性能对比',
        description: '对value1列进行平方操作，对比不同方法的时间。',
        codeTemplate: `# apply方法
start = time.time()
df['square1'] = df['value1'].apply(lambda x: x ** 2)
apply_time = time.time() - start

# 向量化方法（推荐！）
start = time.time()
df['square2'] = df['value1'] ** 2
vectorized_time = time.time() - start

print(f"apply方法耗时: {apply_time:.4f}秒")
print(f"向量化方法耗时: {vectorized_time:.4f}秒")
print(f"加速比: {apply_time / vectorized_time:.2f}x")`,
        expectedOutput: '向量化远快于apply的对比结果。'
      },
      {
        id: 5,
        title: '步骤5：按需加载列',
        description: '模拟只读取需要的列，减少内存。',
        codeTemplate: `# 模拟：只加载需要的列
cols_to_use = ['id', 'category', 'value1']
df_small = df[cols_to_use].copy()

print(f"全量数据内存: {df.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB")
print(f"按需加载内存: {df_small.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB")
print(f"节省: {(1 - df_small.memory_usage(deep=True).sum() / df.memory_usage(deep=True).sum()) * 100:.1f}%")

print("\\n性能优化总结:")
print("1. 使用向量化操作代替apply/map")
print("2. 合理使用category类型")
print("3. 用eval/query加速复杂表达式")
print("4. 按需加载只需要的列")
print("5. 大数据考虑分块处理")`,
        expectedOutput: '内存占用更小的结果和优化总结。'
      }
    ]
  }
];

export const getProjectById = (id: number): Project | undefined => {
  return projects.find(p => p.id === id);
};
