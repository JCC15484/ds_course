import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getProjectById } from '../data/projects';
import PracticeEditor from '../components/PracticeEditor';

const ProjectDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [result, setResult] = useState('');
  const [isCorrect, setIsCorrect] = useState(false);
  
  const projectId = id ? parseInt(id) : 1;
  const project = getProjectById(projectId);

  useEffect(() => {
    if (!project) {
      navigate('/projects');
      return;
    }
    setCurrentStepIndex(0);
    setResult('');
    setIsCorrect(false);
  }, [projectId, navigate]);

  if (!project) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-[#1a365d] dark:text-white mb-4">
            项目未找到
          </h2>
          <button
            onClick={() => navigate('/projects')}
            className="px-6 py-2 bg-[#4299e1] hover:bg-[#2c5282] text-white rounded-lg font-medium transition-colors"
          >
            返回项目列表
          </button>
        </div>
      </div>
    );
  }

  const currentStep = project.steps[currentStepIndex];

  const handleCodeSubmit = (output: string) => {
    setResult(output);
    
    const outputLower = output.toLowerCase();
    let correct = false;
    
    if (currentStepIndex === 0) {
      correct = outputLower.includes('head') || 
                outputLower.includes('dataframe') ||
                outputLower.includes('shape') ||
                output.includes('1000');
    } else if (currentStepIndex === 1) {
      correct = outputLower.includes('无效日期') || 
                outputLower.includes('日期') ||
                output.includes('1000') ||
                output.includes('行');
    } else if (currentStepIndex === 2) {
      correct = outputLower.includes('amount') || 
                outputLower.includes('month') ||
                outputLower.includes('year') ||
                output.includes('特征');
    } else if (currentStepIndex === 3) {
      correct = outputLower.includes('group') || 
                outputLower.includes('sum') ||
                outputLower.includes('top') ||
                output.includes('月') ||
                output.includes('产品');
    } else if (currentStepIndex === 4) {
      correct = outputLower.includes('pivot') || 
                outputLower.includes('pivot_table') ||
                outputLower.includes('product') ||
                output.includes('透视');
    }
    
    setIsCorrect(correct);
  };

  const handleStepChange = (index: number) => {
    setCurrentStepIndex(index);
    setResult('');
    setIsCorrect(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <button
            onClick={() => navigate('/projects')}
            className="mb-4 flex items-center gap-2 text-[#4299e1] hover:text-[#2c5282] font-medium transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            返回项目列表
          </button>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-4xl">{project.icon}</span>
                  <div>
                    <h1 className="text-2xl font-bold text-[#1a365d] dark:text-white">
                      {project.title}
                    </h1>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full text-sm">
                        {project.difficulty}
                      </span>
                      <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full text-sm">
                        {project.duration}
                      </span>
                      {project.tags.map(tag => (
                        <span key={tag} className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full text-sm">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mt-2">
                  {project.description}
                </p>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-bold text-[#1a365d] dark:text-white mb-3 flex items-center gap-2">
                <span className="text-xl">🎯</span>
                学习目标
              </h3>
              <ul className="space-y-2">
                {project.learningGoals.map((goal, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-gray-600 dark:text-gray-400">
                    <span className="text-[#4299e1] mt-1">•</span>
                    <span>{goal}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-3">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 sticky top-20">
              <h3 className="font-bold text-[#1a365d] dark:text-white mb-4">📚 学习步骤</h3>
              <div className="space-y-2">
                {project.steps.map((step, idx) => (
                  <button
                    key={step.id}
                    onClick={() => handleStepChange(idx)}
                    className={`w-full text-left p-3 rounded-lg transition-colors text-sm ${
                      idx === currentStepIndex
                        ? 'bg-[#4299e1] text-white'
                        : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-bold">{idx + 1}.</span>
                      <span>{step.title.replace(/步骤\d+：/, '')}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-9">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-[#1a365d] dark:text-white">
                  {currentStep.title}
                </h2>
                <div className="flex gap-2">
                  {currentStepIndex > 0 && (
                    <button
                      onClick={() => handleStepChange(currentStepIndex - 1)}
                      className="px-4 py-2 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg font-medium text-sm transition-colors"
                    >
                      ← 上一步
                    </button>
                  )}
                  {currentStepIndex < project.steps.length - 1 && (
                    <button
                      onClick={() => handleStepChange(currentStepIndex + 1)}
                      className="px-4 py-2 bg-[#4299e1] hover:bg-[#2c5282] text-white rounded-lg font-medium text-sm transition-colors"
                    >
                      下一步 →
                    </button>
                  )}
                </div>
              </div>
              
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {currentStep.description}
              </p>

              <div className="bg-yellow-50 dark:bg-yellow-900/30 p-4 rounded-lg border border-yellow-200 dark:border-yellow-800">
                <h3 className="font-bold text-yellow-800 dark:text-yellow-200 mb-2 flex items-center gap-2">
                  <span>💡</span> 预期输出
                </h3>
                <p className="text-yellow-800 dark:text-yellow-200 text-sm">
                  {currentStep.expectedOutput}
                </p>
              </div>
            </div>

            <PracticeEditor
              initialCode=""
              title={`步骤 ${currentStepIndex + 1}: ${currentStep.title}`}
              answer={currentStep.codeTemplate}
              onCodeSubmit={handleCodeSubmit}
            />

            {result && (
              <div className={`mt-6 p-6 rounded-xl border-4 ${
                isCorrect 
                  ? 'bg-green-50 border-green-500 dark:bg-green-900/30' 
                  : 'bg-orange-50 border-orange-500 dark:bg-orange-900/30'
              }`}>
                <div className="flex items-center gap-3 mb-3">
                  <span className={`text-4xl ${isCorrect ? 'animate-bounce' : ''}`}>
                    {isCorrect ? '✅' : '🤔'}
                  </span>
                  <h3 className={`text-xl font-bold ${
                    isCorrect 
                      ? 'text-green-700 dark:text-green-300' 
                      : 'text-orange-700 dark:text-orange-300'
                  }`}>
                    {isCorrect ? '回答正确！' : '继续加油！'}
                  </h3>
                </div>
                
                <div className={`text-sm ${
                  isCorrect 
                    ? 'text-green-700 dark:text-green-300' 
                    : 'text-orange-700 dark:text-orange-300'
                }`}>
                  {isCorrect ? (
                    <p>✅ 你的代码成功执行并产生了预期的输出！继续下一道题目吧！</p>
                  ) : (
                    <>
                      <p>💡 提示：</p>
                      <ul className="list-disc list-inside mt-2 space-y-1">
                        <li>确保代码能正常运行（无错误）</li>
                        <li>检查是否产生了预期的数据</li>
                        <li>可以点击"查看答案"按钮查看参考代码</li>
                      </ul>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetail;
