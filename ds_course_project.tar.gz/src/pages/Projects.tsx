import { Link } from 'react-router-dom';
import { projects } from '../data/projects';

const Projects = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#1a365d] dark:text-white mb-2">
            💼 实战项目案例
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            10个完整的Pandas数据分析实战项目，从入门到精通，边学边练，快速提升实战能力
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <Link
              key={project.id}
              to={`/projects/${project.id}`}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all hover:-translate-y-1"
            >
              <div className={`bg-gradient-to-br ${project.color} p-6 text-white`}>
                <div className="flex items-start justify-between">
                  <div className="text-4xl">{project.icon}</div>
                  <div className="flex flex-col gap-1">
                    <span className="px-2 py-1 bg-white/20 rounded text-xs">
                      {project.difficulty}
                    </span>
                    <span className="px-2 py-1 bg-white/20 rounded text-xs">
                      {project.duration}
                    </span>
                  </div>
                </div>
                <div className="mt-4">
                  <h3 className="text-lg font-bold">{project.title}</h3>
                  <p className="text-white/80 text-sm mt-1">
                    {project.category}
                  </p>
                </div>
              </div>
              <div className="p-4">
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-1 mb-4">
                  {project.tags.map(tag => (
                    <span key={tag} className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#4299e1] font-medium">
                      开始学习 →
                    </span>
                    <span className="text-gray-500 dark:text-gray-400">
                      {project.steps.length} 个步骤
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-12 bg-blue-50 dark:bg-gray-800 rounded-xl p-6">
          <h3 className="text-lg font-bold text-[#1a365d] dark:text-white mb-4 flex items-center gap-2">
            📖 项目学习说明
          </h3>
          <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
            <li className="flex items-start gap-2">
              <span>•</span>
              <span>每个项目包含完整的学习目标、分步骤教学和可运行代码</span>
            </li>
            <li className="flex items-start gap-2">
              <span>•</span>
              <span>提供Pyodide在线运行环境，无需安装Python，直接在浏览器中运行代码</span>
            </li>
            <li className="flex items-start gap-2">
              <span>•</span>
              <span>从入门到挑战级别的项目，循序渐进提升Pandas实战能力</span>
            </li>
            <li className="flex items-start gap-2">
              <span>•</span>
              <span>覆盖数据分析全流程，包括数据清洗、处理、分析、可视化等</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Projects;
