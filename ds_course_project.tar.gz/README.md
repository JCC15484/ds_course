# 🎉 部署包说明

## 文件列表

- `ds_course_deploy.tar.gz` - 完整的项目部署包（248KB）
- `deploy.cjs` - 一键部署脚本

---

## 🚀 快速部署（3分钟完成）

### 方法一：下载并部署

1. **下载部署包**
   ```
   下载 ds_course_deploy.tar.gz 文件
   ```

2. **解压文件**
   ```bash
   tar -xzvf ds_course_deploy.tar.gz
   cd ds_course
   ```

3. **安装依赖**
   ```bash
   npm install
   ```

4. **构建项目**
   ```bash
   npm run build
   ```

5. **部署到 GitHub**

   ```bash
   # 配置 Git 用户
   git config user.name "JCC15484"
   git config user.email "14739592707@163.com"

   # 添加文件并提交
   git add -A
   git commit -m "添加10个Pandas实战项目"

   # 推送（使用你的 token）
   git push https://JCC15484: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@github.com/JCC15484/ds_course.git master
   ```

6. **启用 GitHub Pages**
   - 访问：https://github.com/JCC15484/ds_course/settings/pages
   - Source: `Deploy from a branch`
   - Branch: `master` / (root)
   - 点击 Save

7. **访问你的网站**
   ```
   https://JCC15484.github.io/ds_course/
   ```

---

### 方法二：使用自动化脚本

解压后运行：
```bash
chmod +x deploy.cjs
./deploy.cjs
```

脚本会自动：
- ✅ 配置 Git 用户信息
- ✅ 添加所有文件
- ✅ 提交更改
- ✅ 推送到 GitHub

---

## 📦 项目包含的功能

### 1. 首页功能
- Banner 轮播
- 学习路线导航（可点击跳转）
- 热门课程展示
- **新增：实战项目案例板块**
- 每日练习入口
- 平台功能介绍

### 2. 10个完整Pandas实战项目
1. 📊 **销售数据基础分析**（入门）
2. 🛒 **购物篮分析**（进阶）
3. 📈 **用户行为漏斗分析**（进阶）
4. 💎 **RFM客户价值分析**（进阶）
5. 📉 **股票数据技术分析**（挑战）
6. 💬 **文本数据情感分析**（入门）
7. 🔗 **多表关联与数据整合**（进阶）
8. 🧹 **缺失值与异常值处理**（入门）
9. 📊 **数据透视与多维度交叉分析**（挑战）
10. ⚡ **大数据分块处理与性能优化**（挑战）

### 3. 项目详情页功能
- ✅ **代码编辑区初始为空** - 用户需要自己编写代码
- ✅ **自动判题功能** - 运行代码后自动判断对错
- ✅ **参考答案功能** - 可以查看参考代码
- ✅ **学习步骤导航** - 左侧步骤列表，点击切换
- ✅ **代码运行和结果展示** - 使用 Pyodide 在浏览器中运行 Python

### 4. 其他页面
- 📚 课程中心
- ✍️ 练习题库（选择题 + 实操题）
- 👤 个人中心
- 💬 社区

---

## ⚠️ 常见问题

### Q1: 推送时报错 "Permission denied"

**解决方案**：
1. 检查 Token 是否正确
2. 检查 Token 是否有过期
3. 重新生成 Token，确保有 `repo` 权限

### Q2: GitHub Pages 没有更新

**解决方案**：
1. 等待 2-3 分钟
2. 检查 Actions 日志是否有错误
3. 手动触发 Deploy

### Q3: 页面显示空白

**解决方案**：
1. 检查浏览器控制台是否有错误
2. 确认 GitHub Pages Source 设置正确
3. 清除浏览器缓存

---

## 🔧 技术栈

- **前端框架**: React 18
- **构建工具**: Vite
- **样式**: Tailwind CSS
- **路由**: React Router
- **Python 运行环境**: Pyodide (浏览器内运行 Python)
- **代码编辑器**: Monaco Editor

---

## 📞 帮助

如果遇到问题，请检查：
1. Node.js 版本（建议 v18+）
2. npm 版本（建议 v9+）
3. Git 配置
4. 网络连接

---

**祝你部署成功！🎉**
