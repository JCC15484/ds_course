#!/usr/bin/env python3
"""通过 GitHub API 推送完整项目"""
import os
import base64
import json
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

# 配置
REPO_OWNER = "JCC15484"
REPO_NAME = "ds_course"
BRANCH = "master"
TOKEN = "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"

def api_request(method, url, data=None):
    """发起 GitHub API 请求"""
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json"
    }
    
    req = Request(url, headers=headers, method=method)
    
    if data:
        req.data = json.dumps(data).encode("utf-8")
    
    try:
        with urlopen(req, timeout=30) as response:
            return json.loads(response.read()), response.status
    except HTTPError as e:
        print(f"  ❌ 错误 {e.code}")
        return None, e.code


def get_files_to_upload(base_dir):
    """获取所有要上传的文件"""
    files = []
    base_path = Path(base_dir)
    
    # 源代码文件
    src_path = base_path / "src"
    for file_path in src_path.rglob("*"):
        if file_path.is_file():
            files.append(
                (str(file_path.relative_to(base_path)), str(file_path))
            )
    
    # 配置文件
    config_files = [
        "package.json", "package-lock.json",
        "tsconfig.json", "vite.config.ts",
        "tailwind.config.js", "postcss.config.js",
        "index.html", ".gitignore",
        "README.md", "eslint.config.js"
    ]
    for f in config_files:
        if (base_path / f).exists():
            files.append((f, str(base_path / f)))
    
    # 构建产物
    dist_path = base_path / "dist"
    if dist_path.exists():
        for file_path in dist_path.rglob("*"):
            if file_path.is_file():
                files.append(
                    (str(file_path.relative_to(base_path)), str(file_path))
                )
    
    return files


def upload_file(repo_path, local_path):
    """上传单个文件"""
    print(f"📤 {repo_path}")
    
    full_path = Path(local_path)
    
    if not full_path.exists():
        print(f"  ❌ 文件不存在")
        return False
    
    # 读取并编码文件
    with open(full_path, "rb") as f:
        content = base64.b64encode(f.read()).decode("utf-8")
    
    # 检查文件是否存在以获取 SHA
    check_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{repo_path}?ref={BRANCH}"
    check_result, check_status = api_request("GET", check_url)
    
    # 准备上传数据
    data = {
        "message": f"更新 {repo_path}",
        "content": content,
        "branch": BRANCH
    }
    
    if check_status == 200 and check_result.get("sha"):
        data["sha"] = check_result["sha"]
    
    # 上传文件
    upload_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{repo_path}"
    _, status = api_request("PUT", upload_url, data)
    
    if status in [200, 201]:
        print(f"  ✅ 成功")
        return True
    else:
        print(f"  ❌ 失败")
        return False


def main():
    print("=" * 50)
    print("🚀 开始通过 GitHub API 推送完整项目...")
    print("=" * 50)
    print()
    
    base_dir = Path(__file__).parent
    files = get_files_to_upload(base_dir)
    
    print(f"准备上传 {len(files)} 个文件...")
    print()
    
    success = 0
    total = len(files)
    
    for repo_path, local_path in files:
        if upload_file(repo_path, local_path):
            success += 1
    
    print()
    print("=" * 50)
    print(f"✅ 完成! 成功上传 {success}/{total} 个文件")
    print("=" * 50)
    print()
    print("🌐 你的网站地址:")
    print(f"   https://{REPO_OWNER}.github.io/{REPO_NAME}/")
    print()
    print("📋 记得启用 GitHub Pages:")
    print("   https://github.com/JCC15484/ds_course/settings/pages")
    print("   Source: Deploy from a branch")
    print("   Branch: master / dist 文件夹")
    
    if success > 0:
        print("\n🎉 成功上传了文件！现在去 GitHub 启用 Pages 吧！")


if __name__ == "__main__":
    main()
