#!/usr/bin/env node

const { execSync } = require('child_process');
const path = require('path');

const repoUrl = 'https://JCC15484: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@github.com/JCC15484/ds_course.git';

console.log('🚀 开始部署...\n');

try {
  // 配置 git
  console.log('📝 配置 Git 用户信息...');
  execSync('git config user.name "JCC15484"', { cwd: __dirname, stdio: 'inherit' });
  execSync('git config user.email "14739592707@163.com"', { cwd: __dirname, stdio: 'inherit' });

  // 设置远程仓库
  console.log('\n🔗 设置远程仓库...');
  execSync(`git remote set-url origin ${repoUrl}`, { cwd: __dirname, stdio: 'inherit' });

  // 添加所有文件
  console.log('\n📦 添加所有文件...');
  execSync('git add -A', { cwd: __dirname, stdio: 'inherit' });

  // 检查是否有更改
  const status = execSync('git status --short', { cwd: __dirname }).toString();
  if (status.trim()) {
    // 提交
    console.log('\n💾 提交更改...');
    execSync('git commit -m "添加10个Pandas实战项目"', { cwd: __dirname, stdio: 'inherit' });
  } else {
    console.log('\n✅ 没有新更改需要提交');
  }

  // 推送
  console.log('\n⬆️ 推送到 GitHub...');
  execSync('git push origin master', { cwd: __dirname, stdio: 'inherit' });

  console.log('\n✅ 部署成功！');
  console.log('🌐 你的网站将在以下地址访问：');
  console.log('   https://JCC15484.github.io/ds_course/');
  console.log('\n📋 如果 GitHub Pages 未自动部署，请手动配置：');
  console.log('   1. 访问 https://github.com/JCC15484/ds_course/settings/pages');
  console.log('   2. Source 选择 "Deploy from a branch"');
  console.log('   3. Branch 选择 "master" / (root)');
  console.log('   4. 点击 Save');

} catch (error) {
  console.error('\n❌ 部署失败:', error.message);
  process.exit(1);
}
