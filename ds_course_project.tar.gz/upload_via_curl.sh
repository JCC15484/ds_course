#!/bin/bash

# GitHub 配置
REPO_OWNER="JCC15484"
REPO_NAME="ds_course"
BRANCH="master"
TOKEN="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"

echo "🚀 开始上传文件..."
echo "------------------------"

# 文件列表
files=(
    "dist/index.html"
    "dist/assets/index-BJgp5M2e.css"
    "dist/assets/index-CN-se-Qo.js"
    "src/pages/Home.tsx"
    "src/pages/Projects.tsx"
    "src/pages/ProjectDetail.tsx"
    "src/data/projects.ts"
    "src/components/PracticeEditor.tsx"
    "README.md"
)

success_count=0
total_count=${#files[@]}

for file in "${files[@]}"; do
    echo -e "\n📤 上传: $file"
    
    if [ ! -f "$file" ]; then
        echo "   ❌ 文件不存在"
        continue
    fi
    
    # Base64 编码文件内容
    content=$(base64 -w 0 "$file")
    
    # 获取现有 SHA
    sha=$(curl -s -H "Authorization: token $TOKEN" \
        "https://api.github.com/repos/$REPO_OWNER/$REPO_NAME/contents/$file?ref=$BRANCH" \
        | python3 -c "import sys, json; d = json.load(sys.stdin); print(d.get('sha', ''))" 2>/dev/null || true)
    
    # 准备 JSON 数据
    json_data="{\"message\":\"更新 $file\",\"content\":\"$content\",\"branch\":\"$BRANCH\""
    if [ -n "$sha" ]; then
        json_data="$json_data,\"sha\":\"$sha\""
    fi
    json_data="$json_data}"
    
    # 上传文件
    response=$(curl -s -w "%{http_code}" -X PUT \
        -H "Authorization: token $TOKEN" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "https://api.github.com/repos/$REPO_OWNER/$REPO_NAME/contents/$file" \
        2>/dev/null)
    
    http_code=$(echo "$response" | tail -n 1)
    if [ "$http_code" = "200" ] || [ "$http_code" = "201" ]; then
        echo "   ✅ 成功!"
        success_count=$((success_count + 1))
    else
        echo "   ❌ 失败 (HTTP $http_code)"
    fi
done

echo -e "\n------------------------"
echo "✅ 完成! $success_count/$total_count 文件已成功上传"
echo ""
echo "🌐 你的网站地址:"
echo "   https://$REPO_OWNER.github.io/$REPO_NAME/"
echo ""
echo "📋 记得启用 GitHub Pages:"
echo "   https://github.com/JCC15484/ds_course/settings/pages"
echo "   Source: Deploy from a branch"
echo "   Branch: master / (root)"
