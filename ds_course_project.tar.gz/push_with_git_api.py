#!/usr/bin/env python3
"""使用 GitHub Git Data API 推送"""
import os
import base64
import json
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

# 配置
REPO_OWNER = "JCC15484"
REPO_NAME = "ds_course"
BRANCH = "master"
TOKEN = "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"


def api_request(method, url, data=None):
    """发起 GitHub API 请求"""
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json"
    }
    
    req = Request(url, headers=headers, method=method)
    
    if data:
        req.data = json.dumps(data).encode("utf-8")
    
    try:
        with urlopen(req, timeout=30) as response:
            return json.loads(response.read()), response.status
    except HTTPError as e:
        print(f"  ❌ 错误 {e.code}: {e.read().decode('utf-8', errors='ignore')[:200]}")
        return None, e.code


def get_current_commit():
    """获取当前分支的最新提交"""
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/refs/heads/{BRANCH}"
    result, status = api_request("GET", url)
    if status == 200:
        return result["object"]["sha"]
    return None


def create_blob(content):
    """创建 blob"""
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/blobs"
    data = {
        "content": content,
        "encoding": "base64"
    }
    result, status = api_request("POST", url, data)
    if status == 201:
        return result["sha"]
    return None


def create_tree(base_tree_sha, files):
    """创建 tree"""
    tree_items = []
    
    for repo_path, local_path in files:
        full_path = Path(local_path)
        if not full_path.exists():
            continue
            
        with open(full_path, "rb") as f:
            content = base64.b64encode(f.read()).decode("utf-8")
        
        blob_sha = create_blob(content)
        if blob_sha:
            tree_items.append({
                "path": repo_path,
                "mode": "100644",
                "type": "blob",
                "sha": blob_sha
            })
    
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/trees"
    data = {
        "base_tree": base_tree_sha,
        "tree": tree_items
    }
    result, status = api_request("POST", url, data)
    if status == 201:
        return result["sha"]
    return None


def create_commit(tree_sha, parent_sha, message):
    """创建 commit"""
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/commits"
    data = {
        "message": message,
        "tree": tree_sha,
        "parents": [parent_sha]
    }
    result, status = api_request("POST", url, data)
    if status == 201:
        return result["sha"]
    return None


def update_ref(commit_sha):
    """更新分支引用"""
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/refs/heads/{BRANCH}"
    data = {
        "sha": commit_sha,
        "force": True
    }
    result, status = api_request("PATCH", url, data)
    return status in [200, 201]


def get_files(base_dir):
    """获取要上传的文件（只传关键文件）"""
    files = []
    base_path = Path(base_dir)
    
    # 只传 dist 文件夹的内容用于 GitHub Pages
    dist_path = base_path / "dist"
    if dist_path.exists():
        for file_path in dist_path.rglob("*"):
            if file_path.is_file():
                files.append(
                    (str(file_path.relative_to(base_path)), str(file_path))
                )
    
    # 传源代码和配置文件
    important_files = [
        "src/pages/Home.tsx",
        "src/pages/Projects.tsx",
        "src/pages/ProjectDetail.tsx",
        "src/data/projects.ts",
        "src/components/PracticeEditor.tsx",
        "package.json",
        "vite.config.ts",
        "README.md"
    ]
    
    for f in important_files:
        full_path = base_path / f
        if full_path.exists():
            files.append((f, str(full_path)))
    
    return files


def main():
    print("=" * 50)
    print("🚀 使用 Git Data API 推送...")
    print("=" * 50)
    print()
    
    base_dir = Path(__file__).parent
    
    # 获取当前提交
    print("📋 获取当前提交...")
    current_sha = get_current_commit()
    if not current_sha:
        print("❌ 无法获取当前提交")
        return
    print(f"   当前 SHA: {current_sha[:8]}")
    print()
    
    # 获取文件
    print("📁 收集文件...")
    files = get_files(base_dir)
    print(f"   找到 {len(files)} 个文件")
    print()
    
    # 创建 tree
    print("🌳 创建 tree...")
    tree_sha = create_tree(current_sha, files)
    if not tree_sha:
        print("❌ 无法创建 tree")
        return
    print(f"   Tree SHA: {tree_sha[:8]}")
    print()
    
    # 创建 commit
    print("📝 创建 commit...")
    commit_sha = create_commit(
        tree_sha,
        current_sha,
        "更新项目：添加10个Pandas实战项目和像素风格UI"
    )
    if not commit_sha:
        print("❌ 无法创建 commit")
        return
    print(f"   Commit SHA: {commit_sha[:8]}")
    print()
    
    # 更新引用
    print("🔄 更新分支...")
    if update_ref(commit_sha):
        print("✅ 成功！")
        print()
        print("🌐 网站地址: https://JCC15484.github.io/ds_course/")
        print()
        print("📋 现在去 GitHub 启用 Pages:")
        print("   https://github.com/JCC15484/ds_course/settings/pages")
    else:
        print("❌ 更新失败")


if __name__ == "__main__":
    main()
