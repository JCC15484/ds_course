#!/usr/bin/env python3
"""通过 GitHub API 推送项目文件"""
import os
import base64
import json
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

# 配置
REPO_OWNER = "JCC15484"
REPO_NAME = "ds_course"
BRANCH = "master"
TOKEN = "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"

# 要推送的文件列表
FILES = [
    ("dist/index.html", "首页"),
    ("dist/assets/index-BJgp5M2e.css", "样式"),
    ("dist/assets/index-CN-se-Qo.js", "JS文件"),
    ("dist/assets/__vite-browser-external-BIHI7g3E.js", "浏览器兼容"),
    ("dist/favicon.svg", "图标"),
    ("src/pages/Home.tsx", "首页组件"),
    ("src/pages/Projects.tsx", "项目列表"),
    ("src/pages/ProjectDetail.tsx", "项目详情"),
    ("src/data/projects.ts", "项目数据"),
    ("src/components/PracticeEditor.tsx", "代码编辑器"),
    ("README.md", "说明文档")
]


def api_request(method, url, data=None):
    """发起 GitHub API 请求"""
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json"
    }
    
    req = Request(url, headers=headers, method=method)
    
    if data:
        req.data = json.dumps(data).encode("utf-8")
    
    try:
        with urlopen(req, timeout=30) as response:
            return json.loads(response.read()), response.status
    except HTTPError as e:
        print(f"  ❌ 错误 {e.code}: {e.read()}")
        return None, e.code


def upload_file(file_path, description):
    """上传单个文件"""
    print(f"📤 上传: {file_path} ({description})")
    
    full_path = Path(__file__).parent / file_path
    
    if not full_path.exists():
        print(f"  ❌ 文件不存在: {file_path}")
        return False
    
    # 读取并编码文件
    with open(full_path, "rb") as f:
        content = base64.b64encode(f.read()).decode("utf-8")
    
    # 检查文件是否存在以获取 SHA
    check_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{file_path}?ref={BRANCH}"
    check_result, check_status = api_request("GET", check_url)
    
    # 准备上传数据
    data = {
        "message": f"更新 {file_path}",
        "content": content,
        "branch": BRANCH
    }
    
    if check_status == 200 and check_result.get("sha"):
        data["sha"] = check_result["sha"]
    
    # 上传文件
    upload_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{file_path}"
    _, status = api_request("PUT", upload_url, data)
    
    if status in [200, 201]:
        print(f"  ✅ 成功!")
        return True
    else:
        print(f"  ❌ 失败!")
        return False


def main():
    print("=" * 50)
    print("🚀 开始通过 GitHub API 推送项目...")
    print("=" * 50)
    print()
    
    success = 0
    total = len(FILES)
    
    for file_path, description in FILES:
        if upload_file(file_path, description):
            success += 1
    
    print()
    print("=" * 50)
    print(f"✅ 完成! 成功上传 {success}/{total} 个文件")
    print("=" * 50)
    print()
    print("🌐 你的网站地址:")
    print(f"   https://{REPO_OWNER}.github.io/{REPO_NAME}/")
    print()
    print("📋 记得启用 GitHub Pages:")
    print("   https://github.com/JCC15484/ds_course/settings/pages")
    print("   Source: Deploy from a branch")
    print("   Branch: master / (root)")
    
    if success > 0:
        print("\n🎉 成功上传了文件！现在去 GitHub 启用 Pages 吧！")


if __name__ == "__main__":
    main()
